﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Logging.Infrastructures
{
    public interface ILogging
    {
        string Execute(string message);
    }

    public class ConsoleLog : ILogging
    {
        public string Execute(string message)
        {
            return message;
        }
    }
}
