﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Logging.Infrastructures;
using Logging.Models;
using Logging.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Logging.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger _logger;
        private readonly ILogging _logging;

        public HomeController(ILoggerFactory logger, ILogging logging)
        {
            //Categorize the Logs
            _logger = logger.CreateLogger("MyCategory");
            _logging = logging;
        }

        public IActionResult Index()
        {
            ViewBag.text= _logging.Execute("This Is From ConsoleLog Interface :)");
            //----You can see log levels in output window
            int a = 30;
            int b = 60;
            int c = a + b;
            _logger.LogTrace($"This Is Trace Log Level 30+60={c}");

            _logger.LogDebug("This Is Debug Log Level");

            _logger.LogInformation("This Is Information Log Level");
            //using EventId for each Log
            _logger.LogInformation(LogEventId.SomeInformation, "This Is Information Log Level");
            _logger.LogInformation(LogEventId.SpecificInformation, "This Is Information Log Level");

            try
            {
                throw new Exception("This Is Error");
            }
            catch (Exception ex)
            {
                _logger.LogError(LogEventId.SomeError ,ex,"This Is Error Log Level"); 
            }

            _logger.LogWarning("This Is Warning Log Level");

            try
            {
                throw new Exception("This Is Error");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(LogEventId.SpecificError,ex,"This Is Critical Log Level");
            }
           
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
