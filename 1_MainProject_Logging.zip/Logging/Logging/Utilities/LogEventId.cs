﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Logging.Utilities
{
    public static class LogEventId
    {
        public const int SomeInformation = 4000;
        public const int SpecificInformation = 4001;

        public const int SomeError = 4002;
        public const int SpecificError = 4003;

    }
}
